# ClassQuoteGen
